//
//  Gigi.h
//  Gigi
//
//  Created by qiliu on 2017/7/26.
//  Copyright © 2017年 qiliu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIViewController+Gigi.h"

//! Project version number for Gigi.
FOUNDATION_EXPORT double GigiVersionNumber;

//! Project version string for Gigi.
FOUNDATION_EXPORT const unsigned char GigiVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Gigi/PublicHeader.h>



//
//  UIViewController+Gigi.h
//  Gigi
//
//  Created by qiliu on 2017/7/26.
//  Copyright © 2017年 qiliu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <objc/runtime.h>

@interface UIViewController (Gigi)

@end
